#ifndef BRAZOSONAMBULO3D_HPP
#define BRAZOSONAMBULO3D_HPP

#include "obj3dlib.hpp"
#include <string.h>


class BrazoSonambulo3D : public Objeto3D{
private:

public:
  BrazoSonambulo3D();
  ~BrazoSonambulo3D();

};

#endif

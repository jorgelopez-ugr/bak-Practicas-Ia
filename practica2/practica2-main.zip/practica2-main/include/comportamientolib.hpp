#ifndef COMPORTAMIENTOLIB
#define COMPORTAMIENTOLIB

#include "comportamientos/comportamiento.hpp"

#include "../Comportamientos_Jugador/jugador.hpp"
#include "../Comportamientos_Jugador/aldeano.hpp"
#include "../Comportamientos_Jugador/perro.hpp"
#include "../Comportamientos_Jugador/colaborador.hpp"



#endif
